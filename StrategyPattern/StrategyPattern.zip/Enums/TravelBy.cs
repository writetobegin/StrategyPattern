﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.Enums
{
    public enum TravelBy
    {
        Bus = 1,
        Car = 2,
        Taxi=3,
        //Bike=4
    }
}
