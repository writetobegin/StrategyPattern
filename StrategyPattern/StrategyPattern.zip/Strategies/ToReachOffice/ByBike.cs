﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StrategyPattern.Enums;
using StrategyPattern.Interface.Strategies;

namespace StrategyPattern.Strategies.ToReachOffice
{
    //public class ByBike : IToReachOffice
    //{
    //    public TravelBy TravelBy => TravelBy.Bike;
    //    public void Duration()
    //    {
    //        Console.WriteLine("By bike will take 30 minutes ");
    //    }
    //}
}
